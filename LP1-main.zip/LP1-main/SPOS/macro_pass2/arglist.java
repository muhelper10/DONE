
public class arglist {
	String argname,value;
	arglist(String argument) {
		this.argname=argument;
		this.value="";
	}
}
